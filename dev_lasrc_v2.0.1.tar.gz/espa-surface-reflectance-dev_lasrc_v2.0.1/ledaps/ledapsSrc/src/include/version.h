#define VERSION "LIBTIFF, Version 3.5.201\nCopyright (c) 1988-1996 Sam Leffler\nCopyright (c) 1991-1996 Silicon Graphics, Inc."
